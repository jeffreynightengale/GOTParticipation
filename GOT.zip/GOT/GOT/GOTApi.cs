﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GOT
{
    class GOTApi
    {
        public string quote {get;set; }
        public string character {get;set; }
    }
}
